var ele = document.getElementById("full-container");
ele.style.visibility = 'hidden';
function myFun() {
    ele.style.visibility = 'visible';
}   